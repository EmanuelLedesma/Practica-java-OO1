package test;

import modelo.Circulo;
import modelo.Punto;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Punto puntol = new Punto(2, 3);
		Punto punto2 = new Punto(3, 5);
		Punto punto3 = new Punto(2, 31);

		Circulo circulol = new Circulo(puntol, 10);
		Circulo circulo2 = new Circulo(punto3, 10);

		System.out.println(circulol.equals(circulo2));

	}

}
